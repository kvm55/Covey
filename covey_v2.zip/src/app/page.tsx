import Hero from "../components/Hero/Hero";

export default function HomePage() {
  return (
    <main>
      <Hero />
      {/* Add more home sections here as needed */}
    </main>
  );
}